const express = require('express');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3001;
const ADMIN_PASSWORD = '52ywq1314..';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../dist')));

const db = new sqlite3.Database(path.join(__dirname, 'blog.db'));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    summary TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// 获取所有文章
app.get('/api/posts', (req, res) => {
  db.all('SELECT * FROM posts ORDER BY created_at DESC', [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// 获取单篇文章
app.get('/api/posts/:id', (req, res) => {
  db.get('SELECT * FROM posts WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (!row) {
      res.status(404).json({ error: '文章不存在' });
      return;
    }
    res.json(row);
  });
});

// 创建文章
app.post('/api/posts', (req, res) => {
  const { title, content, summary } = req.body;
  if (!title || !content) {
    res.status(400).json({ error: '标题和内容不能为空' });
    return;
  }

  const id = uuidv4();
  const finalSummary = summary || content.substring(0, 150) + '...';

  db.run(
    'INSERT INTO posts (id, title, content, summary) VALUES (?, ?, ?, ?)',
    [id, title, content, finalSummary],
    function(err) {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.json({ id, title, content, summary: finalSummary });
    }
  );
});

// 更新文章
app.put('/api/posts/:id', (req, res) => {
  const { title, content, summary } = req.body;
  if (!title || !content) {
    res.status(400).json({ error: '标题和内容不能为空' });
    return;
  }

  const finalSummary = summary || content.substring(0, 150) + '...';

  db.run(
    'UPDATE posts SET title = ?, content = ?, summary = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
    [title, content, finalSummary, req.params.id],
    function(err) {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      if (this.changes === 0) {
        res.status(404).json({ error: '文章不存在' });
        return;
      }
      res.json({ id: req.params.id, title, content, summary: finalSummary });
    }
  );
});

// 删除文章
app.delete('/api/posts/:id', (req, res) => {
  db.run('DELETE FROM posts WHERE id = ?', [req.params.id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (this.changes === 0) {
      res.status(404).json({ error: '文章不存在' });
      return;
    }
    res.json({ message: '删除成功' });
  });
});

// 验证密码
app.post('/api/auth/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    res.json({ success: true, token: 'admin-token' });
  } else {
    res.status(401).json({ error: '密码错误' });
  }
});

// 前端路由
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;