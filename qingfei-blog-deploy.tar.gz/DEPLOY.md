# 青飞的小站 - 腾讯云部署教程

## 项目信息
- 网站名称：青飞的小站
- 域名：qingfei.online
- 备案号：豫ICP备2026013735号-1
- 管理密码：52ywq1314..

---

## 一、服务器准备

### 1. 购买腾讯云轻量服务器
- 系统：Ubuntu Server 24.04 LTS 64bit
- 配置：2核4G或以上
- 地域：选择靠近用户的地域

### 2. 连接服务器

```bash
ssh root@你的服务器IP
```

---

## 二、环境安装

### 1. 更新系统

```bash
apt update && apt upgrade -y
```

### 2. 安装 Node.js 18

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
apt install -y nodejs
node -v  # 验证安装
npm -v
```

### 3. 安装 PM2 进程管理器

```bash
npm install -g pm2
```

### 4. 安装 Nginx

```bash
apt install -y nginx
```

---

## 三、上传项目代码

### 1. 本地打包项目

在本地项目目录执行：

```bash
# 确保已构建前端
npm run build

# 打包整个项目（包含前端dist和后端server）
tar -czvf qingfei-blog.tar.gz dist/ server/ package.json
```

### 2. 上传到服务器

```bash
scp qingfei-blog.tar.gz root@你的服务器IP:/var/www/
```

### 3. 解压并安装依赖

```bash
ssh root@你的服务器IP
cd /var/www
mkdir -p qingfei
tar -xzvf qingfei-blog.tar.gz -C qingfei/
cd qingfei
npm install --production
```

---

## 四、启动后端服务

### 1. 使用 PM2 启动

```bash
cd /var/www/qingfei
pm2 start server/index.js --name "qingfei-blog"
pm2 save
pm2 startup
```

### 2. 查看运行状态

```bash
pm2 status
pm2 logs qingfei-blog
```

---

## 五、配置 Nginx 反向代理

### 1. 创建配置文件

```bash
cat > /etc/nginx/sites-available/qingfei << 'EOF'
server {
    listen 80;
    server_name qingfei.online;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
```

### 2. 启用站点

```bash
ln -s /etc/nginx/sites-available/qingfei /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
```

---

## 六、配置 SSL 证书（HTTPS）

### 1. 安装 Certbot

```bash
apt install -y certbot python3-certbot-nginx
```

### 2. 申请证书

```bash
certbot --nginx -d qingfei.online --non-interactive --agree-tos --email your-email@example.com
```

### 3. 证书自动续期

```bash
certbot renew --dry-run
```

---

## 七、配置域名 DNS

在腾讯云 DNS 解析控制台添加记录：

| 记录类型 | 主机记录 | 记录值 |
|---------|---------|--------|
| A | @ | 你的服务器公网IP |
| A | www | 你的服务器公网IP |

等待 DNS 生效（通常几分钟到几小时）。

---

## 八、开放防火墙端口

```bash
# 允许 HTTP/HTTPS
ufw allow 'Nginx Full'

# 允许 SSH
ufw allow OpenSSH

# 启用防火墙
ufw enable

# 查看状态
ufw status
```

---

## 九、完成部署

访问你的域名：`https://qingfei.online`

管理后台：`https://qingfei.online/admin`
密码：`52ywq1314..`

---

## 十、常用维护命令

```bash
# 查看服务状态
pm2 status

# 查看日志
pm2 logs qingfei-blog

# 重启服务
pm2 restart qingfei-blog

# 重启 Nginx
systemctl restart nginx

# 更新代码后重新构建
cd /var/www/qingfei
npm run build
pm2 restart qingfei-blog
```

---

## 十一、数据备份

数据库文件位置：`/var/www/qingfei/server/blog.db`

```bash
# 手动备份
cp /var/www/qingfei/server/blog.db /var/backups/blog-$(date +%Y%m%d).db

# 自动备份（每天凌晨2点）
crontab -e
# 添加：0 2 * * * cp /var/www/qingfei/server/blog.db /var/backups/blog-$(date +\%Y\%m\%d).db
```